@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
 echo Chua cai dat. Hay chay CAI_DAT_MOI_TRUONG.cmd truoc.
 pause
 exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" "KanScan.py"
exit /b 0
