@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build KanScan v1.4 - EXE onefile khong CMD
chcp 65001 >nul
echo ==========================================================
echo   BUILD KANSCAN v1.4 - EXE ONEFILE, NO CONSOLE
 echo ==========================================================
if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Chua co .venv - dang cai dat...
  call "CAI_DAT_MOI_TRUONG.cmd"
  if errorlevel 1 goto error
)
echo [2/3] Kiem tra thu vien va kiem thu...
".venv\Scripts\python.exe" -m unittest discover -s tests -v > test.log 2>&1
if errorlevel 1 goto tests_failed
echo [3/3] Dang build Windows EXE khong hien CMD...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed ^
 --name "KanScan_v1_4" ^
 --icon "kanscan.ico" ^
 --add-data "templates;templates" ^
 --add-data "kanscan.ico;." ^
 --collect-all "pillow_heif" ^
 --hidden-import "PIL._tkinter_finder" ^
 "KanScan.py" > build.log 2>&1
if errorlevel 1 goto error
if not exist "dist\KanScan_v1_4.exe" goto error
echo BUILD THANH CONG: %CD%\dist\KanScan_v1_4.exe
explorer "%CD%\dist"
pause
exit /b 0
:tests_failed
echo.
echo TEST KHONG DAT. Xem test.log:
if exist test.log powershell -NoProfile -Command "Get-Content 'test.log' -Tail 20"
pause
exit /b 1
:error
echo.
echo BUILD THAT BAI. Kiem tra build.log va setup.log.
if exist build.log powershell -NoProfile -Command "Get-Content 'build.log' -Tail 25"
pause
exit /b 1
