"""KanScan v1.4 - GUI Windows + Flask receiver, không cửa sổ CMD khi dùng pythonw hoặc EXE."""
from __future__ import annotations

import ipaddress
import logging
import os
import socket
import sys
import threading
import webbrowser
from pathlib import Path

import qrcode
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk

import app as engine

LOG_PATH = engine.STATE_DIR / 'kanscan.log'
logging.basicConfig(filename=str(LOG_PATH), level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s', encoding='utf-8')

BG = '#eff8f1'
WHITE = '#ffffff'
DARK = '#1e4937'
GREEN = '#277958'
MUTED = '#758a7c'
BORDER = '#d7e7da'


def ipv4_addresses():
    found = []
    try:
        import psutil
        for interface, items in psutil.net_if_addrs().items():
            for item in items:
                if item.family != socket.AF_INET:
                    continue
                ip = item.address
                try:
                    parsed = ipaddress.ip_address(ip)
                    if parsed.is_loopback or parsed.is_link_local or not parsed.is_private:
                        continue
                except ValueError:
                    continue
                # Thường Ethernet / Wi-Fi ưu tiên hơn các địa chỉ VPN, Docker.
                priority = 0 if ip.startswith('192.168.') else 1 if ip.startswith('10.') else 2
                if any(word in interface.lower() for word in ('virtual', 'vethernet', 'vmware', 'docker', 'loopback', 'wsl')):
                    priority += 4
                found.append((priority, ip))
    except Exception as exc:
        logging.info('psutil address listing skipped: %s', exc)
    try:
        fallback = engine.get_lan_ip()
        if fallback and not fallback.startswith('127.'):
            found.append((3, fallback))
    except Exception:
        pass
    return [ip for _priority, ip in sorted(set(found))] or ['127.0.0.1']


def free_port(preferred):
    for port in range(int(preferred), int(preferred) + 35):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind(('0.0.0.0', port))
                return port
            except OSError:
                pass
    raise RuntimeError('Không tìm thấy cổng trống từ %d đến %d.' % (preferred, preferred+34))


def server_thread(port):
    from waitress import serve
    try:
        serve(engine.app, host='0.0.0.0', port=port, threads=6,
              max_request_body_size=engine.MAX_UPLOAD + 2048)
    except Exception:
        logging.exception('Cannot start KanScan server')


class Desktop(tk.Tk):
    def __init__(self, port, ips):
        super().__init__()
        self.title('KanScan v1.4  •  Quét QR để chụp chứng từ')
        self.geometry('910x605')
        self.minsize(805, 565)
        self.configure(bg=BG)
        try:
            self.iconbitmap(str(engine.APP_DIR / 'kanscan.ico'))
        except Exception:
            pass
        self.port = port
        self.ips = ips
        self.qr_photo = None
        self.preview_photo = None
        self.last_file = None
        self._ui()
        self.after(300, self.update_qr)
        self.after(700, self.refresh)

    def text(self, parent, content, size=11, color=DARK, bold=False, **options):
        lbl = tk.Label(parent, text=content, font=('Segoe UI', size, 'bold' if bold else 'normal'),
                       bg=parent.cget('bg'), fg=color, justify='left', **options)
        return lbl

    def button(self, parent, caption, action, main=False):
        return tk.Button(parent, text=caption, command=action, relief='flat', bd=0,
                         bg=GREEN if main else '#e7f5eb', fg=WHITE if main else GREEN,
                         activebackground='#1e6749' if main else '#d4eada',
                         activeforeground=WHITE if main else GREEN,
                         font=('Segoe UI', 11, 'bold'), padx=17, pady=11, cursor='hand2')

    def _ui(self):
        shell = tk.Frame(self, bg=BG, padx=25, pady=20)
        shell.pack(fill='both', expand=True)
        brand = tk.Frame(shell, bg=BG)
        brand.pack(fill='x', pady=(0, 18))
        self.text(brand, '▧', 29, GREEN, True).pack(side='left', padx=(0, 12))
        header = tk.Frame(brand, bg=BG)
        header.pack(side='left')
        self.text(header, 'KanScan', 24, DARK, True).pack(anchor='w')
        self.text(header, 'v1.4  ·  Chụp A4/A5, tự nhận chiều giấy, lưu JPEG về Windows', 10, MUTED).pack(anchor='w')
        self.state_label = self.text(brand, '● Đang khởi động', 10, '#ac873d', True)
        self.state_label.pack(side='right', padx=12)

        main = tk.Frame(shell, bg=BG)
        main.pack(fill='both', expand=True)
        left = tk.Frame(main, bg=WHITE, highlightbackground=BORDER, highlightthickness=1, padx=21, pady=18)
        left.pack(side='left', fill='both', padx=(0, 13), expand=False)
        right = tk.Frame(main, bg=WHITE, highlightbackground=BORDER, highlightthickness=1, padx=23, pady=19)
        right.pack(side='left', fill='both', expand=True)
        self.text(left, '01  QUÉT MÃ ĐỂ KẾT NỐI', 13, DARK, True).pack(anchor='w')
        self.text(left, 'iPhone / Android chỉ cần mở Camera và quét mã QR.', 10, MUTED,
                  wraplength=290).pack(anchor='w', pady=(5, 9))
        self.qr_label = tk.Label(left, bg=WHITE, width=260, height=260)
        self.qr_label.pack(pady=(1, 11))
        self.text(left, 'Kết nối mạng trên điện thoại', 10, DARK, True).pack(anchor='w')
        self.ip_value = tk.StringVar(value=self.ips[0])
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('K.TCombobox', fieldbackground='#f0f8f2', background='#f0f8f2', foreground=DARK, padding=5)
        self.ip_combo = ttk.Combobox(left, state='readonly', values=self.ips, textvariable=self.ip_value,
                                     font=('Segoe UI', 11), style='K.TCombobox', width=24)
        self.ip_combo.pack(anchor='w', fill='x', pady=(6, 8))
        self.ip_combo.bind('<<ComboboxSelected>>', lambda _e: self.update_qr())
        self.address_text = self.text(left, '', 10, MUTED, wraplength=290)
        self.address_text.pack(anchor='w')
        self.button(left, 'Sao chép địa chỉ mở trên điện thoại', self.copy_link).pack(fill='x', pady=(15, 0))

        self.text(right, '02  CHỤP & LƯU ẢNH', 13, DARK, True).pack(anchor='w')
        self.text(right, 'Chụp A4 hoặc A5. Khi nối dọc, phần mềm giữ đúng tỷ lệ kích thước giấy.', 10, MUTED,
                  wraplength=360).pack(anchor='w', pady=(6, 15))
        self.text(right, 'THƯ MỤC JPEG', 9, MUTED, True).pack(anchor='w')
        self.folder_text = self.text(right, str(engine.OUTPUT), 10, DARK, wraplength=350)
        self.folder_text.pack(anchor='w', pady=(7, 10))
        buttons = tk.Frame(right, bg=WHITE)
        buttons.pack(fill='x')
        self.button(buttons, 'Mở thư mục ảnh', self.open_folder, True).pack(side='left', padx=(0, 10))
        self.button(buttons, 'Đổi thư mục', self.choose_folder).pack(side='left')
        ttk.Separator(right, orient='horizontal').pack(fill='x', pady=(24, 17))
        self.text(right, 'ẢNH VỪA NHẬN · TÊN A → Z ĐỂ XEM CŨ TRƯỚC', 10, MUTED, True).pack(anchor='w')
        self.last_label = self.text(right, 'Chưa có ảnh. Hãy quét QR để bắt đầu.', 10, DARK, wraplength=350)
        self.last_label.pack(anchor='w', pady=(10, 9))
        self.photo_view = tk.Label(right, bg='#f3f8f4', height=148, width=35)
        self.photo_view.pack(anchor='w', fill='x')
        self.text(right, 'Bản gốc: thư mục BAN_GOC kế bên thư mục JPEG.', 9, MUTED).pack(anchor='w', pady=(12, 0))

        self.text(shell, 'Ghi chú: PC và điện thoại cùng mạng Wi-Fi/LAN · Cho phép KanScan qua Windows Firewall (mạng Private) nếu được hỏi.',
                  10, MUTED, wraplength=820).pack(anchor='w', pady=(18, 0))

    def update_qr(self):
        ip = self.ip_value.get()
        url = engine.public_link(ip, self.port)
        qr = qrcode.QRCode(version=None, box_size=6, border=3, error_correction=qrcode.constants.ERROR_CORRECT_M)
        qr.add_data(url)
        qr.make(fit=True)
        pic = qr.make_image(fill_color='#236044', back_color='#ffffff').convert('RGB')
        pic.thumbnail((258, 258))
        self.qr_photo = ImageTk.PhotoImage(pic)
        self.qr_label.configure(image=self.qr_photo, width=258, height=258)
        if ip.startswith('127.'):
            self.address_text.configure(text='Chưa thấy IP LAN. Kiểm tra kết nối Wi-Fi/Ethernet của PC.')
        else:
            self.address_text.configure(text=f'http://{ip}:{self.port}   ·   Tự kết nối, không cần PIN')

    def copy_link(self):
        self.clipboard_clear()
        self.clipboard_append(engine.public_link(self.ip_value.get(), self.port))
        messagebox.showinfo('KanScan', 'Đã sao chép liên kết. Có thể mở trực tiếp trên điện thoại.')

    def open_folder(self):
        try:
            path = str(engine.OUTPUT)
            if sys.platform.startswith('win'):
                os.startfile(path)
            else:
                import subprocess
                subprocess.Popen(['xdg-open', path])
        except Exception as exc:
            messagebox.showerror('Lỗi mở thư mục', str(exc))

    def choose_folder(self):
        result = filedialog.askdirectory(title='Chọn nơi tự lưu JPEG', initialdir=str(engine.OUTPUT))
        if not result:
            return
        try:
            engine.change_output_folder(result)
            self.folder_text.configure(text=str(engine.OUTPUT))
            self.last_file = None
            self.last_label.configure(text='Đã đổi thư mục lưu JPEG.')
            self.photo_view.configure(image='', text='')
        except Exception as exc:
            messagebox.showerror('Không đổi được thư mục', str(exc))

    def refresh(self):
        try:
            # Kiểm tra cổng chạy: khởi động thành công mới hiển thị sẵn sàng.
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(.18)
                ready = sock.connect_ex(('127.0.0.1', self.port)) == 0
            self.state_label.configure(text='● Sẵn sàng nhận ảnh' if ready else '● Đang khởi động',
                                       fg=GREEN if ready else '#ac873d')
            files = sorted(engine.OUTPUT.glob('IMG*.jpeg'), key=lambda p: p.stat().st_mtime, reverse=True)
            if files:
                f = files[0]
                if self.last_file != f:
                    self.last_file = f
                    self.last_label.configure(text=f.name)
                    with Image.open(f) as image:
                        image = image.convert('RGB')
                        image.thumbnail((320, 148))
                        self.preview_photo = ImageTk.PhotoImage(image)
                    self.photo_view.configure(image=self.preview_photo)
        except Exception as exc:
            logging.info('UI refresh exception: %s', exc)
        self.after(2400, self.refresh)


def run():
    try:
        engine.cleanup_old_drafts()
        ips = ipv4_addresses()
        port = free_port(engine.CONFIG.get('port', 18765))
        engine.CURRENT_PORT = port
        engine.CURRENT_LAN_IP = ips[0]
        thread = threading.Thread(target=server_thread, args=(port,), daemon=True, name='KanScanHTTP')
        thread.start()
        if '--headless' in sys.argv:
            print('KanScan started:', engine.public_link(ips[0], port), flush=True)
            print('Output folder:', engine.OUTPUT, flush=True)
            thread.join()
            return
        window = Desktop(port, ips)
        window.mainloop()
    except Exception as exc:
        logging.exception('KanScan startup error')
        if '--headless' in sys.argv:
            raise
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror('Không thể khởi động KanScan',
                             f'{exc}\n\nNhật ký lỗi: {LOG_PATH}')
        root.destroy()
        raise


if __name__ == '__main__':
    run()
