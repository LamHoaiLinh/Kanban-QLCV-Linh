KANSCAN v1.4 - CHUP A4 / A5 - KHONG HIEN CMD
==========================================

THAY DOI SO VOI v1.2
- BO camera nhung (tranh khung camera den khi Safari mo HTTP tren IP noi bo).
- TRO LAI luong chup cua v1.1: CHUP ANH -> xem truoc -> CHUP DON hoac CHUP NOI.
- BO hoan toan thuat toan giam bong v1.2, giu nguyen thuat toan can sang cua v1.1.
- THEM lua chon A4 (mac dinh) / A5 cho tung lan chup, ke ca giua mot bo anh noi.
- Tu nhan chieu doc/ngang theo hinh giay sau cat chinh phoi canh.
- Noi doc voi cung ty le kho giay, khong keo giay A5 to thanh A4.
- GUI Windows khong hien CMD qua .vbs (khi chay Python), va EXE --windowed.

CHAY TREN WINDOWS 10 / 11
1. Giai nen ZIP vao duong dan ngan, vi du C:\KanScan_v1.4
2. Tren MAY DUNG DE BUILD/CAY CHAY BANG PYTHON:
   Chay CAI_DAT_MOI_TRUONG.cmd (can Python 3.11-3.13 64-bit va Internet lan dau).
   File nay se tao .venv trong thu muc KanScan va cai tat ca thu vien.
3. Chay KHOI_DONG_KHONG_CMD.vbs (khong mo cua so den CMD).
4. Chon noi luu anh tren giao dien PC. Cho phep qua Windows Firewall (mang Private) neu duoc hoi.
5. Cho PC/dien thoai cung Wi-Fi/LAN, quet QR hien tren PC.
6. Chon A4 / A5 TRUOC KHI CHUP (mac dinh A4).
7. Bam CHUP ANH -> camera HE THONG mo -> chup va xac nhan tren dien thoai.
8. Sau khi anh duoc xu ly: CHUP DON de luu 1 anh, hoac CHUP NOI de chup them.
   Khi da co 2 anh, chi con CHUP NOI / XONG. Bam XONG de noi va luu JPEG.

BUILD EXE ONEFILE
- Chay BUILD_ONEFILE.cmd. Script tu tao .venv neu chua co va kiem tra test.
- Neu thanh cong, file se nam tai: dist\KanScan_v1_4.exe
- Copy RIENG file EXE sang Windows x64 khac de chay, KHONG CAN Python / .venv.
- Khi DOUBLE-CLICK EXE se hien GUI KanScan, KHONG co bang CMD.
- CMD chi xuat hien khi chay tap tin .cmd dung de CAI DAT/BUILD/TEST, khong phai khi chay EXE.
- Neu co loi, xem %%LOCALAPPDATA%%\KanScan\kanscan.log

QUY TAC NOI A4 / A5 (HO SO THUC TE)
- A4 = 210 x 297 mm; A5 = 148 x 210 mm.
- Chieu ngang/dọc do phần mềm tự nhận theo kích thước vùng tài liệu được cắt.
- A5 NGANG 210 mm + A4 DOC 210 mm -> hai trang bang nhau ve chieu ngang.
- A5 NGANG 210 mm + A4 NGANG 297 mm -> trang A5 rong 70,7% trang A4.
- Trang hep hon nam GIUA nen trang ghep, can hai ben. Chu, chu ky, dau
  giu dung ty le khi thu phong; bo sung bien trang khi can chu khong bop meo.
- Trang co nen toi/khong tim duoc bien giay: phan mem khong the nhan dien
  chieu giay chac chan, se hien canh bao. Hay chup lai du 4 goc trang.
- Xem truoc anh da ghep ngay sau 2 lan chup noi.
- Giu ban goc rieng trong folder BAN_GOC.

TEN FILE VA THU TU
- Ten JPEG IMGyymmdd-HH.MM.SS.jpeg lay theo thoi diem anh dau tien duoc NHAN.
- Neu trung giay: IMG..._02.jpeg, _03.jpeg...
- Trong Windows Explorer, chon 'Sort by' -> 'Name' -> 'Ascending' (Ten A->Z),
  vi nhu vay anh cu nhat se hien o tren, anh moi nhat o duoi.
- Windows quan ly che do sap xep cua tung folder; chuong trinh khong the dam
  bao Explorer tu thay doi che do xep neu nguoi dung da chon cai khac.

VE CAMERa HE THONG VA BONG
- Chuc nang chup su dung camera goc (input capture=environment), khong nhung
  camera nen tranh duoc trang camera den tren HTTP.
- Giao dien camera he thong co the hien chu Trung/Anh tuy ngon ngu may va
  trinh duyet. KanScan khong duoc phep sua chu cua giao dien do.
- Da bo xu ly bong v1.2. Nen dat chung tu noi du sang, xoay huong chup
  tranh de bong dien thoai va tay de len chu. Dung anh goc de doi chieu.

AN TOAN
- Trang QR la duong dan ghep noi, khong can nhap PIN; dung trong mang noi bo
  dang tin cay, KHONG mo cong ra Internet.
- Chung tu co the chua thong tin ke toan, khong chia se QR ra ngoai mang.

MA NGUON / KIEM TRA
- Test: TEST_NHANH.cmd
- Logic ghep: app.py -> compose_vertical_pages, page_geometry
- Camera web: templates/index.html
- Desktop: KanScan.py

CAN THIEP RIENG TUNG ANH KHI CHUP NOI (v1.4)
----------------------------------------------
* Sau khi chup 2, 3,... anh, duoi anh ghep co day ANH 1 / ANH 2 / ANH 3...
* Cham vao hinh thu nho, hoac nhan giu >= 0.58 giay ngay tren vi tri trang do trong anh ghep.
* Bang sua trang hien 3 lua chon:
  - CHUP LAI ANH NAY: may mo camera HE THONG, chup lai de thay dung trang so da chon.
  - CHON 4 GOC GIAY THU CONG: mo anh GOC, keo 4 cham xanh vao goc giay, bam AP DUNG.
  - XOA RIENG ANH NAY: bo dung trang, cac trang con lai giu nguyen va tu danh so lai.
* Co the huy sua, khong anh huong anh cu khi chua bam Ap dung/Chup xong.
* Anh goc chua bi chinh o thu muc tam trong bo dang chup; file cuoi luu vao thu muc JPEG.
* Sau khi bam XONG bo anh da luu, khong sua lai bang giao dien nay duoc.
* V1.4 tiep tuc dung camera he thong tren iPhone/Android, khong su dung camera nhung.
* Van dung thuat toan lam ro chu cua v1.1/v1.3, KHONG dung xu ly bong cua v1.2.
