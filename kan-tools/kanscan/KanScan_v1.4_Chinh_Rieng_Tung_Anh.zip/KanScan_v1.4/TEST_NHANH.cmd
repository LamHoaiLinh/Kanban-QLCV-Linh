@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Chay CAI_DAT_MOI_TRUONG.cmd truoc.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m unittest discover -s tests -v
pause
