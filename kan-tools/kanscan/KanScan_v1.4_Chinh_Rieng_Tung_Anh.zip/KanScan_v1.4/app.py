"""KanScan v1.4 — chỉnh riêng từng trang: thay ảnh, xóa ảnh, chọn bốn góc thủ công.
Không dùng camera nhúng; giữ quy trình chụp v1.1 và thuật toán cân sáng v1.1.
"""
from __future__ import annotations

import io
import math
import base64
import json
import os
import re
import secrets
import shutil
import socket
import sys
import tempfile
import threading
import time
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from functools import wraps

import cv2
import numpy as np
from flask import Flask, jsonify, render_template, request, session, send_file, redirect, url_for
from PIL import Image, ImageOps, UnidentifiedImageError

try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
except ImportError:
    pass

try:
    import qrcode
except ImportError:
    qrcode = None

APP_DIR = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
STATE_DIR = Path(os.environ.get('KANSCAN_HOME', str(Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'KanScan')))
STATE_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_FILE = STATE_DIR / 'config.json'
ACCESS_TOKEN = secrets.token_urlsafe(26)
CURRENT_LAN_IP = None
CURRENT_PORT = None
VN_TIMEZONE = timezone(timedelta(hours=7))
DEFAULT_ROOT = Path.home() / 'Documents' / 'KanScan'
DEFAULT_CONFIG = {
    'output_folder': str(DEFAULT_ROOT / 'ANH_JPEG'),
    'keep_original': True,
    'jpeg_quality': 88,
    'max_page_width': 1800,
    'port': 18765
}
MAX_UPLOAD = 22 * 1024 * 1024
PAPER_MM = {'A4': (210, 297), 'A5': (148, 210)}
MAX_JOIN_PIXELS = 55_000_000
Image.MAX_IMAGE_PIXELS = 50_000_000


def load_config():
    cfg = DEFAULT_CONFIG.copy()
    if CONFIG_FILE.exists():
        try:
            stored = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
            cfg.update({key: value for key, value in stored.items() if key in cfg})
        except (ValueError, OSError):
            raise RuntimeError('Khong doc duoc config.json. Hay sua JSON hoac doi ten tep de tao lai.')
    try:
        cfg['port'] = int(cfg['port'])
        cfg['jpeg_quality'] = max(70, min(95, int(cfg['jpeg_quality'])))
        cfg['max_page_width'] = max(1000, min(2400, int(cfg['max_page_width'])))
    except (ValueError, TypeError):
        raise ValueError('Port, jpeg_quality va max_page_width phai la so nguyen.')
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding='utf-8')
    return cfg


CONFIG = load_config()
OUTPUT = Path(CONFIG['output_folder']).expanduser().resolve()
ROOT = OUTPUT.parent
RAW_ROOT = ROOT / 'BAN_GOC'
DRAFT_ROOT = ROOT / '_DANG_CHUP'
for directory in (OUTPUT, RAW_ROOT, DRAFT_ROOT):
    directory.mkdir(parents=True, exist_ok=True)

app = Flask(__name__, template_folder=str(APP_DIR / 'templates'))
app.config.update(
    SECRET_KEY=secrets.token_hex(32),
    MAX_CONTENT_LENGTH=MAX_UPLOAD,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    PERMANENT_SESSION_LIFETIME=timedelta(days=60),
    SEND_FILE_MAX_AGE_DEFAULT=0,
)
lock = threading.RLock()
failures = {}


def api_error(msg, status=400):
    return jsonify({'ok': False, 'message': msg}), status


def needs_pairing(func):
    @wraps(func)
    def decorated(*args, **kwargs):
        if not authorized():
            return api_error('Điện thoại chưa được ghép nối bằng mã PIN.', 401)
        return func(*args, **kwargs)
    return decorated


def require_local_post(func):
    @wraps(func)
    def decorated(*args, **kwargs):
        # Custom header blocks basic cross-origin forms / CSRF for paired browsers.
        if request.headers.get('X-KanScan') != '1':
            return api_error('Yêu cầu không hợp lệ.', 403)
        return func(*args, **kwargs)
    return decorated


def draft_path(doc_id):
    if not re.fullmatch(r'[0-9a-f]{32}', doc_id or ''):
        raise ValueError('Mã phiên chụp không hợp lệ.')
    return DRAFT_ROOT / doc_id


def metadata(doc_id):
    directory = draft_path(doc_id)
    mf = directory / 'meta.json'
    if not mf.is_file():
        raise FileNotFoundError('Không tìm thấy phiên chụp. Hãy chụp lại.')
    return json.loads(mf.read_text(encoding='utf-8'))


def save_metadata(doc_id, meta):
    directory = draft_path(doc_id)
    tmp = directory / 'meta.tmp'
    tmp.write_text(json.dumps(meta, ensure_ascii=False), encoding='utf-8')
    os.replace(tmp, directory / 'meta.json')


def order_corners(points):
    p = np.asarray(points, dtype=np.float32)
    sums = p.sum(axis=1)
    diffs = np.diff(p, axis=1).ravel()
    return np.array([p[np.argmin(sums)], p[np.argmin(diffs)], p[np.argmax(sums)], p[np.argmax(diffs)]], dtype=np.float32)


def autodetect_crop(img):
    """Ưu tiên an toàn: không tìm được tờ giấy đáng tin cậy thì giữ nguyên ảnh."""
    height, width = img.shape[:2]
    scale = min(1.0, 1050 / max(height, width))
    small = cv2.resize(img, (round(width * scale), round(height * scale))) if scale != 1 else img
    hh, ww = small.shape[:2]
    gray = cv2.cvtColor(small, cv2.COLOR_RGB2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edge = cv2.Canny(blur, 40, 125)
    edge = cv2.morphologyEx(edge, cv2.MORPH_CLOSE, np.ones((5, 5), dtype=np.uint8))
    contours, _ = cv2.findContours(edge, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    candidates = []
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:35]:
        area = cv2.contourArea(contour)
        ratio = area / (hh * ww)
        if not 0.22 <= ratio <= 0.96:
            continue
        poly = cv2.approxPolyDP(contour, 0.022 * cv2.arcLength(contour, True), True)
        if len(poly) != 4 or not cv2.isContourConvex(poly):
            continue
        points = order_corners(poly.reshape(4, 2))
        top_left, top_right, bot_right, bot_left = points
        bw = max(np.linalg.norm(top_right - top_left), np.linalg.norm(bot_right - bot_left))
        bh = max(np.linalg.norm(bot_left - top_left), np.linalg.norm(bot_right - top_right))
        if min(bw, bh) < 120 or max(bw, bh) / max(min(bw, bh), 1) > 5.5:
            continue
        # Avoid tiny internal boxes / logos detected as a whole page.
        rectangularity = area / max(bw * bh, 1)
        if rectangularity < 0.73:
            continue
        candidates.append((area, points))
    if not candidates:
        return img, False
    _, corners = max(candidates, key=lambda x: x[0])
    corners = corners / scale
    a, b, c, d = corners
    new_w = int(max(np.linalg.norm(b-a), np.linalg.norm(c-d)))
    new_h = int(max(np.linalg.norm(d-a), np.linalg.norm(c-b)))
    if not 200 < new_w <= width*1.6 or not 200 < new_h <= height*1.6:
        return img, False
    destination = np.array([[0, 0], [new_w-1, 0], [new_w-1, new_h-1], [0, new_h-1]], dtype=np.float32)
    matrix = cv2.getPerspectiveTransform(corners, destination)
    return cv2.warpPerspective(img, matrix, (new_w, new_h), flags=cv2.INTER_LINEAR, borderValue=(255,255,255)), True


def decode_image(data):
    try:
        with Image.open(io.BytesIO(data)) as opened:
            result = ImageOps.exif_transpose(opened)
            result.load()
            if result.mode != 'RGB':
                result = result.convert('RGB')
            if result.width < 180 or result.height < 180:
                raise ValueError('Ảnh quá nhỏ để đọc chứng từ.')
            if result.width * result.height > 50_000_000:
                raise ValueError('Ảnh vượt quá giới hạn 50 megapixel.')
            return result
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError('Không đọc được ảnh. Hãy thử chụp lại hoặc chuyển sang JPEG.') from exc


def image_processing(pil_image):
    """Cắt mép tự động, xử lý ảnh y hệt v1.1/v1.3."""
    if max(pil_image.size) > 3400:
        pil_image.thumbnail((3400, 3400), Image.Resampling.LANCZOS)
    scan, cropped = autodetect_crop(np.asarray(pil_image))
    return enhance_page(scan), cropped


def enhance_page(scan):
    """Đúng xử lý v1.1/v1.3, không dùng thuật toán khử bóng gây loang."""
    hh, ww = scan.shape[:2]
    target = CONFIG['max_page_width']
    if ww > target:
        scan = cv2.resize(scan, (target, max(1, int(hh * target / ww))), interpolation=cv2.INTER_AREA)
    lab = cv2.cvtColor(scan, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    contrast = cv2.createCLAHE(clipLimit=1.55, tileGridSize=(8, 8)).apply(l)
    contrast = cv2.add(contrast, np.full_like(contrast, 4))
    adjusted = cv2.cvtColor(cv2.merge((contrast, a, b)), cv2.COLOR_LAB2RGB)
    soft = cv2.GaussianBlur(adjusted, (0, 0), 0.85)
    sharp = cv2.addWeighted(adjusted, 1.20, soft, -0.20, 0)
    return Image.fromarray(sharp)


def manual_perspective_crop(pil_image, points):
    """Bốn điểm theo thứ tự TL, TR, BR, BL với tọa độ chuẩn hóa 0..1."""
    if not isinstance(points, list) or len(points) != 4:
        raise ValueError('Cần đúng bốn góc của tờ giấy.')
    coords = []
    for point in points:
        if (not isinstance(point, (list, tuple)) or len(point) != 2
                or any(isinstance(v, bool) or not isinstance(v, (float, int))
                       or not math.isfinite(v) or v < 0 or v > 1 for v in point)):
            raise ValueError('Tọa độ góc giấy không hợp lệ.')
        coords.append([point[0] * (pil_image.width - 1), point[1] * (pil_image.height - 1)])
    corners = np.array(coords, dtype=np.float32)
    area = cv2.contourArea(corners)
    if (not cv2.isContourConvex(corners) or
            area < pil_image.width * pil_image.height * 0.025):
        raise ValueError('Bốn góc cần tạo thành tờ giấy lồi, không giao nhau và đủ lớn.')
    tl, tr, br, bl = corners
    width = round(max(np.linalg.norm(tr - tl), np.linalg.norm(br - bl)))
    height = round(max(np.linalg.norm(bl - tl), np.linalg.norm(br - tr)))
    if min(width, height) < 120:
        raise ValueError('Vùng giấy được chọn quá nhỏ.')
    factor = min(1, 3200 / max(width, height), math.sqrt(15_000_000 / (width * height)))
    width, height = max(1, int(width * factor)), max(1, int(height * factor))
    dest = np.array([[0, 0], [width-1, 0], [width-1, height-1], [0, height-1]], dtype=np.float32)
    matrix = cv2.getPerspectiveTransform(corners, dest)
    rgb = np.asarray(pil_image)
    scan = cv2.warpPerspective(rgb, matrix, (width, height), flags=cv2.INTER_LINEAR,
                               borderMode=cv2.BORDER_CONSTANT, borderValue=(255, 255, 255))
    return enhance_page(scan)


def find_original(directory, number):
    options = sorted(directory.glob(f'raw_{number:02d}.*'))
    if len(options) != 1:
        raise FileNotFoundError('Không tìm thấy duy nhất ảnh gốc của trang này.')
    return options[0]


def remove_join_previews(directory):
    for p in directory.glob('join_preview_*.jpeg'):
        p.unlink(missing_ok=True)


def page_details(meta):
    count = meta['count']
    sizes = meta.get('page_sizes', ['A4'] * count)
    flags = meta.get('cropped_flags', [False] * count)
    result = []
    for i in range(count):
        result.append({'number': i+1, 'paper_size': sizes[i],
                       'cropped': flags[i] if i < len(flags) else False})
    return result


def image_extension(file):
    name = (file.filename or '').lower()
    mime = (file.mimetype or '').lower()
    if name.endswith(('.heic', '.heif')) or 'heic' in mime or 'heif' in mime:
        return '.heic'
    if name.endswith('.png') or mime == 'image/png':
        return '.png'
    if name.endswith('.webp') or mime == 'image/webp':
        return '.webp'
    return '.jpeg'


def unique_destination(timestamp=None):
    """Theo giây chụp đầu tiên; tên IMG... tăng dần khi Explorer sắp xếp A-Z."""
    base = 'IMG' + datetime.fromtimestamp(timestamp or time.time(), VN_TIMEZONE).strftime('%y%m%d-%H.%M.%S')
    dest = OUTPUT / f'{base}.jpeg'
    sequence = 2
    while dest.exists():
        dest = OUTPUT / f'{base}_{sequence:02d}.jpeg'
        sequence += 1
    return dest


def page_geometry(page, paper_size):
    """Tự nhận portrait/landscape từ vùng giấy sau cắt, không cần người dùng chọn."""
    if paper_size not in PAPER_MM:
        raise ValueError('Khổ giấy phải là A4 hoặc A5.')
    narrow, long = PAPER_MM[paper_size]
    landscape = page.width > page.height
    width_mm, height_mm = (long, narrow) if landscape else (narrow, long)
    return width_mm, height_mm, 'Ngang' if landscape else 'Dọc'


def compose_vertical_pages(images, paper_sizes, canvas_width=1800, separator=12,
                           max_pixels=MAX_JOIN_PIXELS):
    """Giữ kích thước vật lý tương đối A4/A5 và chiều giấy tự nhận diện.

    A5 ngang (210mm) có cùng chiều ngang với A4 dọc (210mm).
    A5 ngang (210mm) bằng ~70.7% chiều ngang A4 ngang (297mm).
    Trang nhỏ được canh giữa trên nền trắng, không kéo giãn thành trang lớn.
    """
    if not images or len(images) != len(paper_sizes):
        raise ValueError('Danh sách ảnh hoặc khổ giấy không hợp lệ.')
    physical = [page_geometry(page, size) for page, size in zip(images, paper_sizes)]
    widest = max(geo[0] for geo in physical)
    px_mm = canvas_width / widest
    sizes = [(max(1, round(w * px_mm)), max(1, round(h * px_mm)))
             for w, h, _orientation in physical]
    width = max(width for width, _height in sizes)
    height = sum(height for _width, height in sizes) + separator * (len(sizes) - 1)
    if width * height > max_pixels:
        # Thu nhỏ tỷ lệ toàn bộ ảnh khi ảnh nối quá dài, tránh lỗi bộ nhớ.
        factor = math.sqrt(max_pixels / (width * height)) * 0.97
        sizes = [(max(1, round(w * factor)), max(1, round(h * factor))) for w, h in sizes]
        width = max(w for w, _h in sizes)
        separator = max(2, round(separator * factor))
        height = sum(h for _w, h in sizes) + separator * (len(sizes) - 1)
    if width * height > max_pixels:
        raise ValueError('Bộ ảnh quá dài để ghép. Hãy chia thành hai bộ chứng từ.')
    output = Image.new('RGB', (width, height), 'white')
    cursor = 0
    for image, (page_w, page_h) in zip(images, sizes):
        # Giữ tỷ lệ nội dung gốc để chữ ký, dấu và chữ không bị bóp méo.
        # Khi mép giấy cắt chưa chính xác, dùng viền trắng thay vì kéo giãn.
        scaled = ImageOps.contain(image, (page_w, page_h), Image.Resampling.LANCZOS)
        sheet = Image.new('RGB', (page_w, page_h), 'white')
        sheet.paste(scaled, ((page_w - scaled.width) // 2, (page_h - scaled.height) // 2))
        output.paste(sheet, ((width - page_w) // 2, cursor))
        cursor += page_h + separator
        scaled.close()
        sheet.close()
    return output


def preview_page_bands(doc_id, meta, canvas_width=700, separator=6):
    count=meta['count']
    if count==0:
        return []
    directory=draft_path(doc_id)
    physical=[]
    for i, paper in enumerate(meta.get('page_sizes', ['A4'] * count), 1):
        with Image.open(directory / f'page_{i:02d}.jpeg') as image:
            physical.append(page_geometry(image,paper))
    widest=max(item[0] for item in physical)
    scale=canvas_width/widest
    widths=[max(1,round(item[0]*scale)) for item in physical]
    heights=[max(1,round(item[1]*scale)) for item in physical]
    width=max(widths)
    height=sum(heights)+separator*(count-1)
    if width*height>16_000_000:
        factor=math.sqrt(16_000_000/(width*height))*.97
        heights=[max(1,round(h*factor)) for h in heights]
        separator=max(2,round(separator*factor))
        height=sum(heights)+separator*(count-1)
    result=[]
    y=0
    for i,h in enumerate(heights,1):
        result.append({'number':i,'y0':round(y/height,7),'y1':round((y+h+separator/2)/height,7)})
        y+=h+separator
    result[-1]['y1']=1
    return result


def create_app():
    # Exposed for local smoke tests; routes live on module-level app.
    return app


@app.after_request
def no_cache(response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'no-referrer'
    return response


def authorized():
    address = request.remote_addr or ''
    return address in ('127.0.0.1', '::1') or bool(session.get('paired'))


def public_link(ip=None, port=None):
    address = ip or CURRENT_LAN_IP or get_lan_ip()
    number = port or CURRENT_PORT or CONFIG['port']
    return f'http://{address}:{number}/connect/{ACCESS_TOKEN}'


def change_output_folder(directory):
    """Đổi nơi lưu file mà không cần cài đặt lại."""
    global OUTPUT, ROOT, RAW_ROOT, DRAFT_ROOT
    new_output = Path(directory).expanduser().resolve()
    new_output.mkdir(parents=True, exist_ok=True)
    new_root = new_output.parent
    (new_root / 'BAN_GOC').mkdir(exist_ok=True)
    (new_root / '_DANG_CHUP').mkdir(exist_ok=True)
    with lock:
        OUTPUT, ROOT = new_output, new_root
        RAW_ROOT, DRAFT_ROOT = ROOT / 'BAN_GOC', ROOT / '_DANG_CHUP'
        CONFIG['output_folder'] = str(new_output)
        CONFIG_FILE.write_text(json.dumps(CONFIG, ensure_ascii=False, indent=2), encoding='utf-8')
    return new_output


@app.get('/connect/<token>')
def connect(token):
    if not secrets.compare_digest(token, ACCESS_TOKEN):
        return 'QR không hợp lệ. Hãy quét lại QR trong KanScan trên PC.', 403
    session.permanent = True
    session['paired'] = True
    return redirect(url_for('home'), code=302)


@app.route('/')
def home():
    if not authorized():
        return '<html lang="vi"><meta name="viewport" content="width=device-width,initial-scale=1"><div style="font:18px system-ui;margin:44px auto;max-width:460px">Vui lòng quét mã QR trên máy tính để mở KanScan.</div></html>', 403
    return render_template('index.html')


@app.get('/api/status')
def status():
    if not authorized():
        return api_error('Quét lại mã QR trên PC để kết nối.', 401)
    return jsonify({'ok': True, 'connected': True})


@app.post('/api/start')
@require_local_post
@needs_pairing
def start():
    doc_id = uuid.uuid4().hex
    directory = draft_path(doc_id)
    directory.mkdir(parents=True, exist_ok=False)
    save_metadata(doc_id, {'count': 0, 'created': time.time(), 'finished': False, 'filename': None, 'page_sizes': [], 'captured_at': [], 'cropped_flags': [], 'manual_corners': []})
    return jsonify({'ok': True, 'id': doc_id, 'count': 0})


@app.get('/api/draft/<doc_id>')
@needs_pairing
def get_draft(doc_id):
    try:
        meta = metadata(doc_id)
    except (ValueError, FileNotFoundError):
        return api_error('Phiên chụp không còn tồn tại.', 404)
    return jsonify({'ok': True, 'count': meta['count'], 'finished': meta['finished'],
                    'filename': meta['filename'], 'page_sizes': meta.get('page_sizes', []),
                    'pages': page_details(meta), 'preview_bands': preview_page_bands(doc_id, meta)})


@app.post('/api/add/<doc_id>')
@require_local_post
@needs_pairing
def add_photo(doc_id):
    try:
        with lock:
            meta = metadata(doc_id)
            if meta['finished']:
                return api_error('Phiên chụp đã hoàn tất. Hãy bắt đầu lượt mới.')
            if meta['count'] >= 15:
                return api_error('Một ảnh nối tối đa 15 phần để tránh file quá lớn.')
            incoming = request.files.get('photo')
            if incoming is None:
                return api_error('Không tìm thấy ảnh gửi lên.')
            data = incoming.read(MAX_UPLOAD + 1)
            if len(data) > MAX_UPLOAD:
                return api_error('Ảnh lớn hơn 22 MB.')
            if not data:
                return api_error('Ảnh bị trống.')
            page_size = request.form.get('paper_size', 'A4').upper()
            if page_size not in PAPER_MM:
                return api_error('Hãy chọn khổ giấy A4 hoặc A5.')
            pil = decode_image(data)
            processed, cropped = image_processing(pil)
            _width_mm, _height_mm, orientation = page_geometry(processed, page_size)
            number = meta['count'] + 1
            directory = draft_path(doc_id)
            original = directory / f'raw_{number:02d}{image_extension(incoming)}'
            processed_path = directory / f'page_{number:02d}.jpeg'
            tmp = directory / f'page_{number:02d}.tmp'
            try:
                tmp.write_bytes(data)  # store original temporarily; rename on success
                processed.save(processed_path, 'JPEG', quality=CONFIG['jpeg_quality'], optimize=True)
                os.replace(tmp, original)
            except Exception:
                tmp.unlink(missing_ok=True)
                processed_path.unlink(missing_ok=True)
                raise
            meta['count'] = number
            meta.setdefault('page_sizes', []).append(page_size)
            meta.setdefault('captured_at', []).append(time.time())
            meta.setdefault('cropped_flags', []).append(bool(cropped))
            meta.setdefault('manual_corners', []).append(None)
            remove_join_previews(directory)
            save_metadata(doc_id, meta)
        return jsonify({'ok': True, 'count': number, 'cropped': cropped,
                        'paper_size': page_size, 'orientation': orientation,
                        'pages': page_details(meta), 'preview': f'/api/preview/{doc_id}/{number}'})
    except FileNotFoundError:
        return api_error('Phiên chụp không còn tồn tại.', 404)
    except ValueError as e:
        return api_error(str(e))


@app.get('/api/original/<doc_id>/<int:number>')
@needs_pairing
def original_preview(doc_id, number):
    """Ảnh gốc đã xoay theo EXIF, thu nhỏ để chỉnh 4 góc trên điện thoại."""
    try:
        with lock:
            meta = metadata(doc_id)
            if number < 1 or number > meta['count']:
                return api_error('Ảnh không tồn tại.', 404)
            with Image.open(find_original(draft_path(doc_id), number)) as opened:
                img = ImageOps.exif_transpose(opened).convert('RGB')
                img.thumbnail((1500, 2000), Image.Resampling.LANCZOS)
                output = io.BytesIO()
                img.save(output, 'JPEG', quality=86)
        output.seek(0)
        return send_file(output, mimetype='image/jpeg', download_name=f'raw_{number:02d}.jpeg')
    except (ValueError, FileNotFoundError, OSError):
        return api_error('Không mở được ảnh gốc.', 404)


@app.post('/api/manual-crop/<doc_id>/<int:number>')
@require_local_post
@needs_pairing
def manual_crop_page(doc_id, number):
    try:
        with lock:
            meta = metadata(doc_id)
            if meta['finished']:
                return api_error('Bộ ảnh đã hoàn tất, không thể sửa.')
            if number < 1 or number > meta['count']:
                return api_error('Số trang không hợp lệ.', 404)
            payload = request.get_json(silent=True) or {}
            points = payload.get('corners')
            directory = draft_path(doc_id)
            original = find_original(directory, number)
            with Image.open(original) as opened:
                normalized = ImageOps.exif_transpose(opened).convert('RGB')
            cropped = manual_perspective_crop(normalized, points)
            temp = directory / f'.manual_{number:02d}.tmp'
            try:
                cropped.save(temp, 'JPEG', quality=CONFIG['jpeg_quality'], optimize=True)
                os.replace(temp, directory / f'page_{number:02d}.jpeg')
            finally:
                temp.unlink(missing_ok=True)
            flags = meta.setdefault('cropped_flags', [False] * meta['count'])
            flags[number - 1] = True
            corners = meta.setdefault('manual_corners', [None] * meta['count'])
            corners[number - 1] = points
            remove_join_previews(directory)
            save_metadata(doc_id, meta)
            _a, _b, orientation = page_geometry(cropped, meta['page_sizes'][number-1])
        return jsonify({'ok': True, 'number': number, 'orientation': orientation,
                        'pages': page_details(meta)})
    except (FileNotFoundError, ValueError, OSError, cv2.error) as exc:
        return api_error(str(exc))


@app.post('/api/replace/<doc_id>/<int:number>')
@require_local_post
@needs_pairing
def replace_page(doc_id, number):
    try:
        with lock:
            meta = metadata(doc_id)
            if meta['finished']:
                return api_error('Bộ ảnh đã hoàn tất, không thể thay.')
            if number < 1 or number > meta['count']:
                return api_error('Số trang không hợp lệ.', 404)
            uploaded = request.files.get('photo')
            if not uploaded:
                return api_error('Chưa chọn ảnh để thay.')
            raw = uploaded.read(MAX_UPLOAD + 1)
            if not raw or len(raw) > MAX_UPLOAD:
                return api_error('Ảnh trống hoặc vượt giới hạn 22 MB.')
            paper_size = request.form.get('paper_size', meta['page_sizes'][number-1]).upper()
            if paper_size not in PAPER_MM:
                return api_error('Chỉ hỗ trợ A4/A5.')
            processed, cropped = image_processing(decode_image(raw))
            directory = draft_path(doc_id)
            ext = image_extension(uploaded)
            new_original = directory / f'raw_{number:02d}{ext}'
            stage_original = directory / f'.raw_replace_{number:02d}.tmp'
            stage_page = directory / f'.page_replace_{number:02d}.tmp'
            try:
                stage_original.write_bytes(raw)
                processed.save(stage_page, 'JPEG', quality=CONFIG['jpeg_quality'], optimize=True)
                # Chuẩn bị cả 2 tệp thành công mới thay trang.
                os.replace(stage_page, directory / f'page_{number:02d}.jpeg')
                for old in directory.glob(f'raw_{number:02d}.*'):
                    old.unlink(missing_ok=True)
                os.replace(stage_original, new_original)
            finally:
                stage_original.unlink(missing_ok=True)
                stage_page.unlink(missing_ok=True)
            meta['page_sizes'][number-1] = paper_size
            meta.setdefault('cropped_flags', [False] * meta['count'])[number-1] = bool(cropped)
            meta.setdefault('manual_corners', [None] * meta['count'])[number-1] = None
            remove_join_previews(directory)
            save_metadata(doc_id, meta)
            _a, _b, orientation = page_geometry(processed, paper_size)
        return jsonify({'ok': True, 'number': number, 'cropped': cropped, 'orientation': orientation,
                        'pages': page_details(meta)})
    except (FileNotFoundError, ValueError, OSError) as exc:
        return api_error(str(exc))


@app.delete('/api/page/<doc_id>/<int:number>')
@require_local_post
@needs_pairing
def delete_page(doc_id, number):
    """Xóa chính xác một trang, dồn các trang còn lại liên tục đúng thứ tự."""
    try:
        with lock:
            meta = metadata(doc_id)
            if meta['finished']:
                return api_error('Bộ ảnh đã hoàn tất, không thể xóa.')
            if number < 1 or number > meta['count']:
                return api_error('Số trang không hợp lệ.', 404)
            directory = draft_path(doc_id)
            count = meta['count']
            # Đưa dữ liệu còn lại vào staging trước; lỗi khi sao chép không làm mất bộ ảnh.
            staging = directory / ('_renumber_' + uuid.uuid4().hex)
            staging.mkdir()
            try:
                for old_num in range(1, count + 1):
                    if old_num == number:
                        continue
                    new_num = old_num if old_num < number else old_num - 1
                    shutil.copy2(directory / f'page_{old_num:02d}.jpeg',
                                 staging / f'page_{new_num:02d}.jpeg')
                    old_raw = find_original(directory, old_num)
                    shutil.copy2(old_raw, staging / f'raw_{new_num:02d}{old_raw.suffix}')
                for old in directory.glob('page_*.jpeg'):
                    old.unlink()
                for old in directory.glob('raw_*'):
                    old.unlink()
                for staged in staging.iterdir():
                    os.replace(staged, directory / staged.name)
            finally:
                shutil.rmtree(staging, ignore_errors=True)
            for key in ('page_sizes', 'captured_at', 'cropped_flags', 'manual_corners'):
                if key in meta and len(meta[key]) >= number:
                    meta[key].pop(number - 1)
            meta['count'] -= 1
            remove_join_previews(directory)
            save_metadata(doc_id, meta)
        return jsonify({'ok': True, 'count': meta['count'], 'pages': page_details(meta)})
    except (FileNotFoundError, ValueError, OSError) as exc:
        return api_error(str(exc))


@app.get('/api/preview/<doc_id>/<int:number>')
@needs_pairing
def preview(doc_id, number):
    try:
        meta = metadata(doc_id)
        if number < 1 or number > meta['count']:
            return api_error('Ảnh không hợp lệ.', 404)
        return send_file(draft_path(doc_id) / f'page_{number:02d}.jpeg', mimetype='image/jpeg')
    except (ValueError, FileNotFoundError):
        return api_error('Ảnh không tồn tại.', 404)


@app.get('/api/join-preview/<doc_id>')
@needs_pairing
def join_preview(doc_id):
    """Xem trước một ảnh đã nối dọc sau từng lần chụp nối."""
    try:
        with lock:
            meta = metadata(doc_id)
            count = meta['count']
            if count < 2:
                return api_error('Cần ít nhất hai ảnh để xem ảnh nối.', 400)
            directory = draft_path(doc_id)
            target = directory / f'join_preview_{count:02d}.jpeg'
            if not target.exists():
                images = []
                try:
                    for i in range(1, count + 1):
                        with Image.open(directory / f'page_{i:02d}.jpeg') as opened:
                            images.append(opened.convert('RGB'))
                    sizes = meta.get('page_sizes', ['A4'] * count)
                    result = compose_vertical_pages(images, sizes, canvas_width=700,
                                                    separator=6, max_pixels=16_000_000)
                    try:
                        result.save(target, 'JPEG', quality=76, optimize=True)
                    finally:
                        result.close()
                finally:
                    for im in images:
                        im.close()
        return send_file(target, mimetype='image/jpeg')
    except (FileNotFoundError, ValueError):
        return api_error('Không tạo được ảnh xem trước.', 404)


@app.post('/api/finish/<doc_id>')
@require_local_post
@needs_pairing
def finish(doc_id):
    mode = str((request.get_json(silent=True) or {}).get('mode', ''))
    if mode not in ('single', 'join'):
        return api_error('Chế độ lưu không hợp lệ.')
    try:
        with lock:
            meta = metadata(doc_id)
            if meta['finished']:
                return jsonify({'ok': True, 'filename': meta['filename'], 'count': meta['count']})
            count = meta['count']
            if mode == 'single' and count != 1:
                return api_error('Chụp đơn phải có đúng một ảnh.')
            if mode == 'join' and count < 2:
                return api_error('Chụp nối cần ít nhất hai ảnh.')
            directory = draft_path(doc_id)
            images = []
            try:
                for i in range(1, count+1):
                    with Image.open(directory / f'page_{i:02d}.jpeg') as f:
                        images.append(f.convert('RGB'))
                if count == 1:
                    final = images[0]
                else:
                    sizes = meta.get('page_sizes', ['A4'] * count)
                    final = compose_vertical_pages(images, sizes)
                temp_name = OUTPUT / ('.kanscan_' + doc_id + '.tmp')
                try:
                    with temp_name.open('wb') as f:
                        final.save(f, 'JPEG', quality=CONFIG['jpeg_quality'], optimize=True)
                        f.flush()
                        os.fsync(f.fileno())
                    final_path = unique_destination(meta.get('captured_at', [meta['created']])[0])
                    os.replace(temp_name, final_path)
                finally:
                    temp_name.unlink(missing_ok=True)
            finally:
                if len(images) > 1 and 'final' in locals():
                    final.close()
                for im in images:
                    im.close()
            if CONFIG['keep_original']:
                # Originals remain recoverable if color correction/cropping was wrong.
                raw_directory = RAW_ROOT / final_path.stem
                raw_directory.mkdir(parents=True, exist_ok=True)
                for src in directory.glob('raw_*'):
                    shutil.copy2(src, raw_directory / src.name)
            meta['finished'] = True
            meta['filename'] = final_path.name
            save_metadata(doc_id, meta)
        return jsonify({'ok': True, 'filename': final_path.name, 'count': count})
    except (FileNotFoundError, ValueError) as e:
        return api_error(str(e), 404)


@app.errorhandler(413)
def too_big(_error):
    return api_error('Ảnh quá lớn (trên 22 MB). Giảm độ phân giải rồi thử lại.', 413)


def get_lan_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(('192.0.2.1', 80))
            addr = s.getsockname()[0]
            if addr and not addr.startswith('127.'):
                return addr
    except OSError:
        pass
    try:
        for address in socket.gethostbyname_ex(socket.gethostname())[2]:
            if not address.startswith('127.'):
                return address
    except OSError:
        pass
    return '127.0.0.1'


def cleanup_old_drafts():
    # Only delete temp sessions older than 7 days; original files in BAN_GOC stay untouched.
    oldest = time.time() - 7*24*3600
    for directory in DRAFT_ROOT.iterdir():
        if directory.is_dir() and re.fullmatch(r'[0-9a-f]{32}', directory.name):
            try:
                if directory.stat().st_mtime < oldest:
                    shutil.rmtree(directory)
            except OSError:
                continue


