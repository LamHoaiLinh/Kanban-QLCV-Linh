"""Test flow chụp thật bằng Flask test_client, không cần điện thoại."""
import io
import os
import tempfile
import unittest
from pathlib import Path

TMP = tempfile.TemporaryDirectory(prefix='kanscan_test_')
os.environ['KANSCAN_HOME'] = str(Path(TMP.name) / 'state')

import app as engine
from PIL import Image, ImageDraw


class TestKanScan(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        engine.change_output_folder(str(Path(TMP.name) / 'JPEG'))

    def setUp(self):
        self.client = engine.app.test_client()
        self.remote = {'REMOTE_ADDR': '192.168.1.55'}
        # Điện thoại chưa scan QR không truy cập được.
        self.assertEqual(self.client.get('/', environ_overrides=self.remote).status_code, 403)
        response = self.client.get('/connect/' + engine.ACCESS_TOKEN, environ_overrides=self.remote)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.client.get('/', environ_overrides=self.remote).status_code, 200)

    def photo(self, n=1):
        im = Image.new('RGB', (740, 1040), (227, 233, 226))
        d = ImageDraw.Draw(im)
        d.rectangle((52, 54, 700, 980), fill=(251, 250, 246), outline=(100, 110, 94), width=6)
        d.text((110, 120), 'HOA DON SO ' + str(n), fill=(18, 25, 20))
        d.text((110, 180), 'Tien: 18.500.000 VND', fill=(18, 25, 20))
        data = io.BytesIO()
        im.save(data, 'JPEG', quality=90)
        data.seek(0)
        return data

    def post(self, url, **kwargs):
        return self.client.post(url, environ_overrides=self.remote,
                                headers={'X-KanScan': '1'}, **kwargs)

    def test_single_jpeg(self):
        docid = self.post('/api/start').json['id']
        response = self.post('/api/add/' + docid,
                             data={'photo': (self.photo(1), 'a.jpg')})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json['count'], 1)
        saved = self.post('/api/finish/' + docid, json={'mode': 'single'}).json
        self.assertTrue(saved['ok'])
        self.assertRegex(saved['filename'], r'^IMG\d{6}-\d{2}\.\d{2}\.\d{2}(?:_\d+)?\.jpeg$')
        self.assertTrue((engine.OUTPUT / saved['filename']).is_file())
        self.assertTrue((engine.RAW_ROOT / Path(saved['filename']).stem / 'raw_01.jpeg').exists())

    def test_join_vertical(self):
        docid = self.post('/api/start').json['id']
        for index in range(1, 4):
            result = self.post('/api/add/' + docid,
                               data={'photo': (self.photo(index), f'{index}.jpg')})
            self.assertEqual(result.json['count'], index)
        preview = self.client.get('/api/join-preview/' + docid, environ_overrides=self.remote)
        self.assertEqual(preview.status_code, 200)
        output = self.post('/api/finish/' + docid, json={'mode': 'join'}).json
        self.assertTrue(output['ok'])
        with Image.open(engine.OUTPUT / output['filename']) as result:
            self.assertGreater(result.height, result.width * 2)
        self.assertEqual(len(list((engine.RAW_ROOT / Path(output['filename']).stem).glob('raw_*'))), 3)

    def test_page_sizes_stored_per_photo(self):
        docid = self.post('/api/start').json['id']
        r1 = self.post('/api/add/' + docid,
                       data={'photo': (self.photo(1), 'a.jpg'), 'paper_size': 'A5'})
        self.assertEqual(r1.json['paper_size'], 'A5')
        r2 = self.post('/api/add/' + docid,
                       data={'photo': (self.photo(2), 'b.jpg'), 'paper_size': 'A4'})
        self.assertEqual(r2.json['paper_size'], 'A4')
        draft = self.client.get('/api/draft/' + docid, environ_overrides=self.remote).json
        self.assertEqual(draft['page_sizes'], ['A5', 'A4'])
        saved = self.post('/api/finish/' + docid, json={'mode':'join'}).json
        self.assertTrue(saved['ok'])

    def test_unpaired_api_blocked(self):
        fresh = engine.app.test_client()
        result = fresh.post('/api/start', environ_overrides=self.remote, headers={'X-KanScan':'1'})
        self.assertEqual(result.status_code, 401)

    def test_duplicate_finish_is_idempotent(self):
        docid = self.post('/api/start').json['id']
        self.post('/api/add/' + docid, data={'photo': (self.photo(), '1.jpg')})
        r1 = self.post('/api/finish/' + docid, json={'mode':'single'}).json
        r2 = self.post('/api/finish/' + docid, json={'mode':'single'}).json
        self.assertEqual(r1['filename'], r2['filename'])


if __name__ == '__main__':
    unittest.main()
