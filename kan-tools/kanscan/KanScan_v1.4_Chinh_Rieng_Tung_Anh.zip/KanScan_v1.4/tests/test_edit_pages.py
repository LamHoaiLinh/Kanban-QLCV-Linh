"""Chạy `python -m unittest discover -s tests -v` trên PC đã cài venv."""
import io
import unittest
from PIL import Image, ImageDraw
import app as engine


class PageEditingTests(unittest.TestCase):
    def setUp(self):
        self.client=engine.app.test_client()
        self.client.get('/connect/'+engine.ACCESS_TOKEN)
        self.headers={'X-KanScan':'1'}
        self.doc=self.client.post('/api/start',headers=self.headers).json['id']
        for i in range(1,4):
            self.add_photo(i)

    def photo(self, n):
        image=Image.new('RGB',(700,960),'#eeeeea')
        draw=ImageDraw.Draw(image)
        draw.rectangle((80,85,620,870),outline='#333333',width=6,fill='white')
        draw.text((120,130),f'TRANG {n}',fill='black')
        stream=io.BytesIO();image.save(stream,'JPEG');stream.seek(0)
        return stream

    def add_photo(self,n):
        result=self.client.post('/api/add/'+self.doc,headers=self.headers,
            data={'photo':(self.photo(n),f'{n}.jpeg'), 'paper_size':'A4'})
        self.assertEqual(result.status_code,200, result.json)

    def test_replace_only_page_three(self):
        folder=engine.draft_path(self.doc)
        before1=(folder/'page_01.jpeg').read_bytes()
        before2=(folder/'page_02.jpeg').read_bytes()
        result=self.client.post('/api/replace/'+self.doc+'/3',headers=self.headers,
            data={'photo':(self.photo(99),'new.jpg'),'paper_size':'A5'})
        self.assertTrue(result.json['ok'],result.json)
        self.assertEqual((folder/'page_01.jpeg').read_bytes(),before1)
        self.assertEqual((folder/'page_02.jpeg').read_bytes(),before2)
        self.assertEqual(engine.metadata(self.doc)['page_sizes'],['A4','A4','A5'])
        self.assertEqual(self.client.get('/api/join-preview/'+self.doc).status_code,200)

    def test_manual_crop_and_invalid(self):
        folder=engine.draft_path(self.doc)
        before=(folder/'page_01.jpeg').read_bytes()
        points=[[.11,.10],[.89,.10],[.89,.91],[.11,.91]]
        result=self.client.post('/api/manual-crop/'+self.doc+'/3',headers=self.headers,json={'corners':points})
        self.assertTrue(result.json['ok'],result.json)
        self.assertTrue(engine.metadata(self.doc)['cropped_flags'][2])
        self.assertEqual((folder/'page_01.jpeg').read_bytes(),before)
        bad=self.client.post('/api/manual-crop/'+self.doc+'/3',headers=self.headers,
            json={'corners':[[.1,.1],[.9,.9],[.1,.9],[.9,.1]]})
        self.assertEqual(bad.status_code,400)

    def test_delete_middle_and_join_after(self):
        folder=engine.draft_path(self.doc)
        before3=(folder/'page_03.jpeg').read_bytes()
        response=self.client.delete('/api/page/'+self.doc+'/2',headers=self.headers)
        self.assertTrue(response.json['ok'],response.json)
        self.assertEqual(engine.metadata(self.doc)['count'],2)
        self.assertEqual((folder/'page_02.jpeg').read_bytes(),before3)
        self.assertFalse((folder/'page_03.jpeg').exists())
        manifest=self.client.get('/api/draft/'+self.doc).json
        self.assertEqual(len(manifest['preview_bands']),2)
        result=self.client.post('/api/finish/'+self.doc,headers=self.headers,json={'mode':'join'})
        self.assertTrue(result.json['ok'],result.json)

if __name__=='__main__': unittest.main()
