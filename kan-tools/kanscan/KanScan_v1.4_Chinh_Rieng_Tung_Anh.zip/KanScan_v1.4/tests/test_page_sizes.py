"""Test logic khổ giấy. Dùng trong unittest trên Windows sau khi cài môi trường."""
import unittest
from PIL import Image
import app as engine


class PaperMergeTests(unittest.TestCase):
    def test_auto_orientation(self):
        self.assertEqual(engine.page_geometry(Image.new('RGB', (800, 1200)), 'A4'), (210, 297, 'Dọc'))
        self.assertEqual(engine.page_geometry(Image.new('RGB', (1200, 800)), 'A5'), (210, 148, 'Ngang'))

    def test_a5_landscape_a4_portrait_equal_width(self):
        a5 = Image.new('RGB', (1100, 775), '#168ee5')
        a4 = Image.new('RGB', (900, 1273), '#dd4433')
        result = engine.compose_vertical_pages([a5, a4], ['A5', 'A4'], canvas_width=800, separator=8)
        self.assertEqual(result.width, 800)
        self.assertEqual(result.getpixel((0, 20)), (22, 142, 229))
        self.assertEqual(result.getpixel((0, result.height - 20)), (221, 68, 51))

    def test_a5_landscape_a4_landscape_narrower_a5(self):
        a5 = Image.new('RGB', (1100, 775), '#168ee5')
        a4 = Image.new('RGB', (1450, 1025), '#dd4433')
        result = engine.compose_vertical_pages([a5, a4], ['A5', 'A4'], canvas_width=900, separator=9)
        a5_width = round(900 * 210 / 297)
        x_margin = (900-a5_width)//2
        self.assertEqual(result.getpixel((10, 20)), (255, 255, 255))
        self.assertEqual(result.getpixel((x_margin+4, 20)), (22, 142, 229))
        self.assertEqual(result.getpixel((10, result.height - 20)), (221, 68, 51))

    def test_invalid_paper_size(self):
        with self.assertRaises(ValueError):
            engine.page_geometry(Image.new('RGB', (500, 900)), 'LETTER')


if __name__ == '__main__':
    unittest.main()
