@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title KanScan - Cai dat moi truong Python
chcp 65001 >nul
echo ====================================================
echo  KanScan v1.4 - CAI DAT MOI TRUONG DE CHAY / BUILD
 echo ====================================================
if exist ".venv\Scripts\python.exe" goto install
set "PYCMD="
py -3.13 -c "import sys" >nul 2>&1
if not errorlevel 1 set "PYCMD=py -3.13"
if not defined PYCMD (
  py -3.12 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3.12"
)
if not defined PYCMD (
  py -3.11 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3.11"
)
if not defined PYCMD (
  python -c "import sys; assert (3,11) <= sys.version_info[:2] <= (3,13)" >nul 2>&1
  if not errorlevel 1 set "PYCMD=python"
)
if not defined PYCMD (
 echo LOI: May DUNG DE BUILD can Python 3.11/3.12/3.13 64-bit.
 echo May chi DE CHAY file EXE khong can Python.
 pause
 exit /b 1
)
echo [1/3] Tao .venv...
%PYCMD% -m venv .venv
if errorlevel 1 goto error
:install
if not exist ".venv\Scripts\python.exe" goto error
echo [2/3] Cai packages va PyInstaller. Can mang Internet lan dau...
".venv\Scripts\python.exe" -m pip install --upgrade pip > setup.log 2>&1
if errorlevel 1 goto error
".venv\Scripts\python.exe" -m pip install -r requirements.txt "pyinstaller>=6.14,<7" >> setup.log 2>&1
if errorlevel 1 goto error
echo [3/3] Kiem tra...
".venv\Scripts\python.exe" -c "import flask,cv2,PIL,waitress,qrcode,pillow_heif,psutil,PyInstaller,tkinter; print('OK - packages available')"
if errorlevel 1 goto error
echo.
echo THANH CONG. Tiep theo: CHAY_BANG_PYTHON.cmd hoac BUILD_ONEFILE.cmd
pause
exit /b 0
:error
echo.
echo KHONG CAI DUOC. Kiem tra setup.log, Python 64-bit va ket noi Internet.
if exist setup.log powershell -NoProfile -Command "Get-Content 'setup.log' -Tail 14"
pause
exit /b 1
