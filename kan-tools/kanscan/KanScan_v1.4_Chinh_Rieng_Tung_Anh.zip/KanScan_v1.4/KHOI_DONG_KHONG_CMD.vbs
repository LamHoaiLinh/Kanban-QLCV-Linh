' KanScan v1.4 - Khoi dong GUI an cua so terminal hoan toan.
Option Explicit
Dim fso, shell, folder, pythonw, entry
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
pythonw = folder & "\.venv\Scripts\pythonw.exe"
entry = folder & "\KanScan.py"
If Not fso.FileExists(pythonw) Then
  MsgBox "Chua cai dat .venv. Hay chay CAI_DAT_MOI_TRUONG.cmd truoc.", 48, "KanScan v1.4"
  WScript.Quit 1
End If
shell.CurrentDirectory = folder
shell.Run Chr(34) & pythonw & Chr(34) & " " & Chr(34) & entry & Chr(34), 0, False
